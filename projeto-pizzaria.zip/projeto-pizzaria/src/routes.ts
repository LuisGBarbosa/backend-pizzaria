import { Router } from 'express';
import multer from 'multer';

//Controllers
import { CreateUserController } from './controllers/user/CreateUserController';
import { AuthUserController } from './controllers/user/AuthUserController';
import { DetailUserController } from './controllers/user/DetailUserController';

import { CreateCategoryController } from './controllers/category/CreateCategoryController';
import { ListCategoryController } from './controllers/category/ListCategoryController';

import { CreateProductController } from './controllers/product/CreateProductController';
import { ListByCategoryController } from './controllers/product/ListByCategoryController';

import { CreateOrderController } from './controllers/order/CreateOrderController';
import { RemoveOrderController } from './controllers/order/RemoveOrderController';
import { AddItemController } from './controllers/order/AddItemController';

//Middlewars
import { isAuthenticated } from './middlewars/isAuthenticated';
import uploadConfig from './config/multer'; //file upload
import { RemoveItemController } from './controllers/order/RemoveItemController';
import { SendOrderController } from './controllers/order/SendOrderController';
import { ListOrdersController } from './controllers/order/ListOrdersController';
import { DetailOrderController } from './controllers/order/DetailOrderController';
import { FinishOrderController } from './controllers/order/FinishOrderController';

const router = Router();

const uploadImage = multer(uploadConfig.upload("./tmp")); 

// -- ROTAS USER -- //
router.post('/users', new CreateUserController().handle); //cadastrando usuário
router.post('/session', new AuthUserController().handle); //autenticando usuário
router.get('/me', isAuthenticated, new DetailUserController().handle); //buscando dados do usuário

// -- ROTAS CATEGORY -- //
router.post('/category', isAuthenticated, new CreateCategoryController().handle); //criando categoria
router.get('/category', isAuthenticated, new ListCategoryController().handle); //listando categoria

// -- ROTAS PRODUCT -- //
router.post('/product', isAuthenticated, uploadImage.single("file"), new CreateProductController().handle); //cadastrando produto
router.get('/category/product', isAuthenticated, new ListByCategoryController().handle); //listando produtos por categoria

// -- ROTAS ORDERS -- //
router.post('/order', isAuthenticated, new CreateOrderController().handle); //cadastrando order
router.delete('/order', isAuthenticated, new RemoveOrderController().handle); //deletando order

router.post('/order/add', isAuthenticated, new AddItemController().handle); //adicionando item na order
router.delete('/order/remove', isAuthenticated, new RemoveItemController().handle); //deletando um item da order
router.put('/order/send', isAuthenticated, new SendOrderController().handle); //enviando order (Esta rota é put porque apenas altera uma propriedade na order).
router.get('/orders', isAuthenticated, new ListOrdersController().handle); //listando orders
router.get('/order/detail', isAuthenticated, new DetailOrderController().handle); //detalhes da order
router.put('/order/finish', isAuthenticated, new FinishOrderController().handle); //Finalizando order

export { router };