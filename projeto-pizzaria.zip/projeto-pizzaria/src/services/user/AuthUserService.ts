import prismaClient from "../../prisma";
import { compare } from "bcryptjs"; //usado pra comparar senhas {compare}
import { sign } from "jsonwebtoken";

interface AuthRequest {
    email: string,
    password: string
}

class AuthUserService {
    async execute({ email, password }: AuthRequest){
        console.log(password)
        //verificando se o email enviado existe
        const user = await prismaClient.user.findFirst({
            where: {
                email: email
            }
        });
        
        //se o email não existe
        if(!user) {
            throw new Error("Email incorreto.");
        };

        //verificando se a senha está correta
        const passwordMatch = await compare(password, user.password) //comparando senha informada com senha que tá no usuário no banco
    
        //se a senha não existe
        if(!passwordMatch){
            throw new Error("Senha incorreta.");
        };
        

        // gerar token JWT e devolver dados do usuário
        const token = sign(
            { //payload
                name: user.name,
                email: user.email
            },
            //secret key
            process.env.JWT_SECRET,
            {//options
                subject: user.id,
                expiresIn: '30d'
            }
            
        ) 

        return { 
            id: user.id,
            name: user.name,
            email: user.email,
            token: token
         }
    }
}

export { AuthUserService };