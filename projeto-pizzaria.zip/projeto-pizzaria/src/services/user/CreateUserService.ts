import prismaClient from "../../prisma"; //importando const do prismaClient
import { hash } from "bcryptjs"; //importando bcrypt - criptografia de senha

interface userRequest {
    name: string,
    email: string,
    password: string
};

class CreateUserService{
    async execute({ name, email, password }: userRequest){

        //verificar se envou o email
        if(!email) {
            throw new Error('Email incorreto')
        };

        //verificar se o email já está cadastrado
        const userAlreadyExists = await prismaClient.user.findFirst({ //buscar o primeiro registro onde...
            //o email é igual ao que estamos recebendo
            where: {
                email: email
            }
        });

        if(userAlreadyExists){
            throw new Error('Já existe um usuário cadastrado com o email informado')
        }

        //criptografando senha e armazenando em uma variável
        const criptedPass = await hash(password, 8); //como primeiro parâmetro, passamos o que queremos criptografar e em segundo salto em número.

        //cadastrando usuário no banco de dados
        const user = await prismaClient.user.create({ 
            //await esperando o prisma cadastrar o data informado e armazenar na const user
            data: {
                name: name,
                email: email,
                password: criptedPass //ao invés de passar a senha, passamos ela criptografada.
            },
            //o select é pra informar o que queremos devolver, está sendo usado pra não devolver a senha do user
            select: {
                id: true,
                name: true,
                email: true
            }
        });

        return user; //retornando o usuário armazenado na const user
    }
}

export { CreateUserService };