import prismaClient from "../../prisma";

interface OrderRequest {
    order_id: string;
}

class SendOrderService {
    //recebendo id da order, fazendo update na order onde o id é igual o que foi passado, e mudando o campo
    //draft de false pra true, pra tirar do rascunho
    async execute({ order_id }: OrderRequest ){
        const order = await prismaClient.order.update({
            where:{
                id: order_id
            },
            data: {
                draft: false
            }
        })

        return order;
    }
}

export { SendOrderService };