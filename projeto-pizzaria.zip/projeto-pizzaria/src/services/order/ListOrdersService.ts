import prismaClient from "../../prisma";

class ListOrdersService {
    async execute(){
        //retornando pedidos onde os draft é false e status também e em ordem mais recente de cadastro
        const orders = prismaClient.order.findMany({
            where: {
                draft: false,
                status: false
            },
            orderBy: {
                created_at: 'desc'
            }
        });

        return orders;
    }
}

export { ListOrdersService };