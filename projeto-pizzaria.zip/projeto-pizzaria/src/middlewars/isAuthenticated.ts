import { NextFunction, Request, Response } from "express";
import { verify } from "jsonwebtoken"; //método pra verificar token

interface Payload{
    sub: string
};

export function isAuthenticated(req: Request, res: Response, next: NextFunction){
    
    //receber o token
    const authToken = req.headers.authorization;
    

    //verificando se não recebeu o token
    if(!authToken){
        res.status(401).end();
    }
    
    //transformando token em um item do array, a vígula vazia no início, siginifica ignorar o primeiro item
    const [, token] = authToken.split(" "); //separando por espaços
    
    //verificar token
    try {
        //validar token
        const { sub } = verify(
            token, //token
            process.env.JWT_SECRET //secret key
        ) as Payload;  //interface
        
        //criando uma variável na requisição e passando o valor da variável sub(onde tá o id) pra ela
        req.user_id = sub;
        
        return next();
        
    } catch (err) {
        return res.status(401).end();
    }
};