import crypto from 'crypto';
import multer from 'multer';

import { extname, resolve } from 'path';

//salvando imagem
export default {
    upload(folder: string){
        return {
            storage: multer.diskStorage({
                //local     //os pontos são voltando um caminho acima
                destination: resolve(__dirname, '..', '..', folder),
                filename: (request, file, callback) => {
                    const fileHash = crypto.randomBytes(16).toString("hex"); //gerando um hash pra colocar no nome
                    const fileName = `${fileHash}-${file.originalname}` //nome da foto
    
                    return callback(null, fileName);
                }
            })
        }
    }
}