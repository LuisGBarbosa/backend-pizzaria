import express, { Request, Response, NextFunction } from "express";
import 'express-async-errors'; //sempre deixar importado em segundo.
import cors from 'cors';
import path from 'path';

import { router } from './routes'; //importando rotas do arquivo de rotas

const app = express();
app.use(express.json()); //middleware json
app.use(cors()); //middlware utilizando cors - é utilizado pra qualquer ip conseguir fazer requisição, sem nenhum bloqueio.

app.use(router); //middleware utilizando as rotas 

//middleware de rota estática pra visualizar a imagem
app.use(
    '/files',
    express.static(path.resolve(__dirname, '..', 'tmp'))
);

//middleware pra tratar erros de requisição
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    if(err instanceof Error){
        //se o erro recebido em err é uma instância do tipo Error
        return res.status(400).json({
            message: err.message
        });
    }

    //se não for do tipo instanceof Error mas for algum outro ripo de error
    return res.status(500).json({
        status: 'Error',
        message: 'Internal server error'
    });
});


app.listen(3333, () => console.log("Servidor online!"));