declare namespace Express {
    export interface Request {
        user_id: string;
    }
}

//definindo e exportando um tipo pra nova variável que adicionamos na requisição.